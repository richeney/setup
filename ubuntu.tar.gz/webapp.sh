#!/bin/bash

first=Richard
last=Cheney

git clone https://github.com/richeney/azure101-webapp-html
cd azure101-webapp-html
git init
ls -Al
pwd

git config --global user.email "$first.$last@microsoft.com"
git config --global user.name "$first $last"
git config --global credential.helper cache

rg=Azure101PaaS
user=${first}${last}DeployWebApp
pwd=azure101p455w0rd
appName=azure101${first}${last}

az webapp deployment user set --user-name $user --password $pwd
az group create --name $rg --location westeurope
az appservice plan create --name quickStartPlan --resource-group $rg --sku FREE
az webapp create --name $appName --resource-group $rg --plan quickStartPlan
deployuri=$(az webapp deployment source config-local-git --name $appName --resource-group $rg --query url --output tsv)
git remote add azure $deployuri
echo "Your password is $pwd"
git push azure master
